**To enable resource sharing across AWS Organizations**

The following ``enable-sharing-with-aws-organization`` example enables resource sharing across your organization or organizational units. ::

    aws ram enable-sharing-with-aws-organization

The following output indicates success. ::

    {
        "returnValue": true
    }
